const $ = (id) => document.getElementById(id);
function detect(raw) {
  try {
    const u = new URL(raw);
    if (!["https:", "http:"].includes(u.protocol)) return null;
    const h = u.hostname.toLowerCase().replace(/^www\./, "");
    if (h === "youtu.be" && /^[\w-]{11}$/.test(u.pathname.split("/")[1] || ""))
      return "YouTube";
    if (
      ["youtube.com", "m.youtube.com", "music.youtube.com"].includes(h) &&
      ((u.pathname === "/watch" &&
        /^[\w-]{11}$/.test(u.searchParams.get("v") || "")) ||
        /^\/(shorts|live)\/[\w-]{11}\/?$/.test(u.pathname))
    )
      return "YouTube";
    if (
      ["instagram.com", "m.instagram.com"].includes(h) &&
      /^\/(reel|reels|p|tv)\/[\w-]+\/?$/.test(u.pathname)
    )
      return "Instagram";
  } catch {}
  return null;
}
function update() {
  const p = detect($("url").value.trim());
  $("platform").textContent = p
    ? `${p} · Link detected`
    : "Paste a supported video link";
  $("copy").disabled = !p;
  return p;
}
$("url").addEventListener("input", () => {
  update();
  $("title").textContent = "Save something worth keeping";
  $("status").textContent = "";
});
$("copy").addEventListener("click", async () => {
  if (!update()) return;
  try {
    await navigator.clipboard.writeText($("url").value.trim());
    $("status").textContent = "Link copied. Paste it into ReelMind.";
  } catch {
    $("status").textContent =
      "Could not copy. Select and copy the URL manually.";
  }
});
$("open").addEventListener("click", () =>
  chrome.tabs.create({ url: "https://reelmind-henna.vercel.app/" }),
);
(async () => {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (detect(tab?.url)) {
      $("url").value = tab.url;
      $("title").textContent = (tab.title || "Video").slice(0, 150);
    }
  } catch {}
  update();
})();
